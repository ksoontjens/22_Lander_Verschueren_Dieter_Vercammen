package hellotvxlet;

public interface ObserverInterface {
   
    void update(int time, Question question);

}
